<?php

global $wgAllMessagesJv;
$wgAllMessagesJv = array(
);
?>
