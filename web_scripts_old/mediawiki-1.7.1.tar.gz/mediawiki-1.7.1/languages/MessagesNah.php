<?php

global $wgAllMessagesNah;
$wgAllMessagesNah = array(

	# Month names
	'january' => 'Tlacenti',
	'february' => 'Tlaonti',
	'march' => 'Tlayeti',
	'april' => 'Tlanauhtl',
	'may' => 'Tlamacuilti',
	'june' => 'Tlachicuazti',
	'august' => 'Tlachiconti',
	'september' => 'Tlachicnauhti',
	'october' => 'Tlamatlacti',
	'november' => 'Tlamactlihuanceti',
	'december' => 'Tlamactlihuanonti',
	
	# Days of the week
	'monday' => 'Metztlitonal',
	'tuesday' => 'Huitzilopochtonal',
	'wednesday' => 'Yacatlipotonal',
	'thursday' => 'Tezcatlipotonal',
	'friday' => 'Quetzalcoatonal',
	'saturday' => 'Tlaloctitonal',
	'sunday' => 'Tonatiutonal',
	
	# Preferences etc.
	'userlogin' => 'Calaqui / Registrarse',
	'yourlanguage' => 'Tlahtolli:',
	'yourpassword' => 'Tlahtolichtacayo',
	'yourpasswordagain' => 'Tlahtolichtacayo zapa'

);


?>