<?php

/**
 * Samogitian dependencies file
 * See http://mail.wikipedia.org/pipermail/wikitech-l/2006-January/033660.html
 */
 
require_once( 'LanguageLt.php' );

?>