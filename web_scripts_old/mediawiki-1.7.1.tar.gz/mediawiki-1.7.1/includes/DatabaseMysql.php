<?php
/*
 * Stub database class for MySQL.
 */
require_once('Database.php');
?>
