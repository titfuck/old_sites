<?php

# Stub message file for converter code "zh"

$fallback = 'zh-cn';

?>
