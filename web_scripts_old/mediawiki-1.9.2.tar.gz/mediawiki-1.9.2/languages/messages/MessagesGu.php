<?php
/**
  * @package MediaWiki
  * @subpackage Language
  */

$digitTransformTable = array(
	'0' => '૦',
	'1' => '૧',
	'2' => '૨',
	'3' => '૩',
	'4' => '૪',
	'5' => '૫',
	'6' => '૬',
	'7' => '૭',
	'8' => '૮',
	'9' => '૯'
);
?>
