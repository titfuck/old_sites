<?php
/**
 * Uzbek (Oʻzbek)
 *
 * @package MediaWiki
 * @subpackage Language
 */

$linkTrail = '/^([a-zʻʼ]+)(.*)$/sDu';

?>
