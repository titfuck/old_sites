<?php

/**
  * @package MediaWiki
  * @subpackage Language
  */
# Inherit everything for now
$fallback = 'zh-tw';

?>
