<?php
/** Neapolitan (Nnapulitano)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'it';

?>
