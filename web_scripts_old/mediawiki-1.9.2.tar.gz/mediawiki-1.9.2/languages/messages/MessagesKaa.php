<?php
/**
 * Karakalpak (Qaraqalpaqsha)
 *
 * @package MediaWiki
 * @subpackage Language
 */

$linkTrail = '/^([a-zʻ`]+)(.*)$/sDu';

?>
