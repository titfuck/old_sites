<?php
/** Sindhi language file ( सिनधि )
  *
  * @package MediaWiki
  * @subpackage Language
  */

#FIXME: inherit almost everything for now

$rtl = true;

?>
