<?php
/** Kashmiri language file ( कश्मीरी - (ﻚﺸﻤﻳﺮﻳ) )
  *
  * @package MediaWiki
  * @subpackage Language
  */

#FIXME: inherit almost everything for now
$rtl = true;

?>
