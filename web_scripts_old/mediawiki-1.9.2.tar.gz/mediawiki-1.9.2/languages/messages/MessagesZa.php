<?php
/** Zhuang (壮语)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'zh-cn';
?>
