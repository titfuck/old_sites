<?php
/**
 * Bavarian (Boarisch)
 *
 * @package MediaWiki
 * @subpackage Language
 */

$fallback = 'de';

$messages = array(

'mainpage'	=> 'Hauptsaitn',

);

?>
