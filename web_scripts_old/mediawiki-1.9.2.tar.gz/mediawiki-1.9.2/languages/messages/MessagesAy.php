<?php
/** Tahitian (Reo Mā`ohi)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'fr';
?>
