<?php
/** Dhivehi language file ( ދިވެހިބަސް',      )
  *
  * @package MediaWiki
  * @subpackage Language
  */

$rtl = true;
?>
