<?php
/** Guaraní (avañe'ẽ)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'es';
?>
