<?php
/**
  * Serbian
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'sr-ec';
$linkTrail = '/^([abvgdđežzijklljmnnjoprstćufhcčdžšабвгдђежзијклљмнњопрстћуфхцчџш]+)(.*)$/usD';

?>
