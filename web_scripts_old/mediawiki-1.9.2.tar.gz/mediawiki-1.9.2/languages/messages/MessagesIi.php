<?php
/** Yi (ꆇꉙ)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'zh-cn';
?>
