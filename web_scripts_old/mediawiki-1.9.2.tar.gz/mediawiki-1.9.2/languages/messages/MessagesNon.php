<?php
/** Old Norse (Norrǿna)
  *
  * Defaults to Icelandic instead of English.
  *
  * @package MediaWiki
  * @subpackage Language
  */
$fallback = 'is';

?>
